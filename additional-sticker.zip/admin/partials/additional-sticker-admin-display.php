<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://www.asanatsa.cc/project/additional-sticker
 * @since      1.1.0
 *
 * @package    Additional_Sticker
 * @subpackage Additional_Sticker/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
