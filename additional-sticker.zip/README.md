# Additional Sticker

a wordpress plugin for add custom sticker to the comment

一个支持在评论里插入自定义表情贴纸的wordpress插件

default stickers license by [@是我祭祭哒](https://space.bilibili.com/9369485)

默认表情作者：[@是我祭祭哒](https://space.bilibili.com/9369485)，已获得作者授权

## Todo

* [X] 实现基本替换功能
* [ ] 支持上传自定义表情包并进行管理
* [ ] 支持用户创建、编辑成套表情
* [ ] 支持古登堡编辑器（大概
* [X] 优化查询逻辑
